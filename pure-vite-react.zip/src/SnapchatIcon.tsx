import React from 'react';

const SnapchatIcon: React.FC<{ className?: string }> = ({ className }) => {
    return (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill="currentColor"
            className={className}
            width="32"
            height="32"
        >
            <path d="M12 2c-5.523 0-10 4.477-10 10s4.477 10 10 10c.134 0 .267-.003.4-.008.065-2.93.816-5.405 2.124-7.232.32-.44.15-.815-.224-1.127-1.39-1.16-2.99-2.03-4.942-2.31-.38-.056-.56-.337-.56-.713 0-.41.223-.714.56-.714 2.164 0 4.2.86 5.88 2.25.43.35.617.72.336 1.23-1.04 1.9-1.63 4.14-1.63 6.62 0 .1.002.2.004.3.1-5.11 3.2-9 8.5-9 .08 0 .16-.002.24-.003C21.782 5.51 17.26 2 12 2z"></path>
        </svg>
    );
};

export default SnapchatIcon;